/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/utils/api.ts":
/*!**************************!*\
  !*** ./src/utils/api.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fetchAnime": () => (/* binding */ fetchAnime),
/* harmony export */   "getUrlImageRecommend": () => (/* binding */ getUrlImageRecommend)
/* harmony export */ });
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
function fetchAnime(name) {
    return __awaiter(this, void 0, void 0, function* () {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        headers.append('Accept', 'application/json');
        headers.append('GET', 'POST');
        const res = yield fetch(`https://tronghoa.dev/api/anime_search.php?q=${name}`, {
            headers: headers
        });
        if (!res.ok)
            throw new Error('Inaccessible');
        var data = yield res.json();
        console.log(data);
        if (data.length == 0)
            throw new Error('Couldn\'t find the anime you were looking for');
        return data;
    });
}
function getUrlImageRecommend(tags) {
    return `https://tronghoa.dev/api/isset/${tags}.png`;
}


/***/ }),

/***/ "./src/utils/storage.ts":
/*!******************************!*\
  !*** ./src/utils/storage.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStoredAnimes": () => (/* binding */ getStoredAnimes),
/* harmony export */   "getStoredFavouriteAnimes": () => (/* binding */ getStoredFavouriteAnimes),
/* harmony export */   "getStoredOptions": () => (/* binding */ getStoredOptions),
/* harmony export */   "setStoredAnimes": () => (/* binding */ setStoredAnimes),
/* harmony export */   "setStoredFavouriteAnimes": () => (/* binding */ setStoredFavouriteAnimes),
/* harmony export */   "setStoredOptions": () => (/* binding */ setStoredOptions)
/* harmony export */ });
function setStoredFavouriteAnimes(animes_fav) {
    const vals = {
        animes_fav
    };
    return new Promise((resolve) => {
        chrome.storage.local.set(vals, () => {
            resolve();
        });
    });
}
function getStoredFavouriteAnimes() {
    const keys = ["animes_fav"];
    return new Promise((resolve) => {
        chrome.storage.local.get(keys, (res) => {
            var _a;
            resolve((_a = res.animes_fav) !== null && _a !== void 0 ? _a : []);
        });
    });
}
function setStoredAnimes(animes) {
    const vals = {
        animes
    };
    return new Promise((resolve) => {
        chrome.storage.local.set(vals, () => {
            resolve();
        });
    });
}
function getStoredAnimes() {
    const keys = ["animes"];
    return new Promise((resolve) => {
        chrome.storage.local.get(keys, (res) => {
            var _a;
            resolve((_a = res.animes) !== null && _a !== void 0 ? _a : []);
        });
    });
}
function setStoredOptions(options) {
    const vals = {
        options
    };
    return new Promise((resolve) => {
        chrome.storage.local.set(vals, () => {
            resolve();
        });
    });
}
function getStoredOptions() {
    const keys = ['options'];
    return new Promise((resolve) => {
        chrome.storage.local.get(keys, (res) => {
            resolve(res.options);
        });
    });
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!**************************************!*\
  !*** ./src/background/background.ts ***!
  \**************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/storage */ "./src/utils/storage.ts");
/* harmony import */ var _utils_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/api */ "./src/utils/api.ts");


chrome.runtime.onInstalled.addListener(() => {
    (0,_utils_storage__WEBPACK_IMPORTED_MODULE_0__.setStoredAnimes)([]);
    (0,_utils_storage__WEBPACK_IMPORTED_MODULE_0__.setStoredFavouriteAnimes)([]);
    (0,_utils_storage__WEBPACK_IMPORTED_MODULE_0__.setStoredOptions)({
        hasAutoOverlay: true,
        tempScale: 'Un_favourite',
        animePinned: ''
    });
    chrome.contextMenus.create({
        contexts: ["selection"],
        title: "Add this anime to favorites",
        id: 'addAnimetoFavourite'
    });
    chrome.alarms.create({
        periodInMinutes: 1 / 6,
    });
    chrome.tabs.create({
        url: 'https://tronghoa.dev/thank/?install=anime_manager'
    });
});
chrome.contextMenus.onClicked.addListener((event) => {
    (0,_utils_storage__WEBPACK_IMPORTED_MODULE_0__.getStoredFavouriteAnimes)().then((animes) => {
        (0,_utils_storage__WEBPACK_IMPORTED_MODULE_0__.setStoredFavouriteAnimes)([...animes, event.selectionText]);
    });
});
chrome.alarms.onAlarm.addListener(() => {
    (0,_utils_storage__WEBPACK_IMPORTED_MODULE_0__.getStoredOptions)().then((options) => {
        if (options.animePinned === '')
            return;
        (0,_utils_api__WEBPACK_IMPORTED_MODULE_1__.fetchAnime)(options.animePinned).then((data) => {
            setTimeout(() => {
                chrome.action.setBadgeText({
                    text: data[0].name
                });
            }, 1000);
            setTimeout(() => {
                chrome.action.setBadgeText({
                    text: `Scored`
                });
            }, 2000);
            setTimeout(() => {
                chrome.action.setBadgeText({
                    text: data[0].rate
                });
            }, 3000);
        });
    });
});

})();

/******/ })()
;
//# sourceMappingURL=background.js.map